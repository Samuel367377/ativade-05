from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import sqlite3

app = Flask(__name__, static_folder='static', static_url_path='')
CORS(app)

# ---------- BANCO DE DADOS ----------
def conectar():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def criar_tabela():
    conn = conectar()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            descricao TEXT,
            imagem TEXT
        )
    ''')
    conn.commit()
    conn.close()

criar_tabela()


# ---------- ROTAS ----------
@app.route('/produtos', methods=['GET'])
def listar_produtos():
    conn = conectar()
    produtos = conn.execute('SELECT * FROM produtos').fetchall()
    conn.close()
    return jsonify([dict(row) for row in produtos])


@app.route('/produtos', methods=['POST'])
def adicionar_produto():
    dados = request.get_json()
    conn = conectar()
    conn.execute('INSERT INTO produtos (nome, preco, descricao, imagem) VALUES (?, ?, ?, ?)',
                 (dados['nome'], dados['preco'], dados['descricao'], dados['imagem']))
    conn.commit()
    conn.close()
    return jsonify({'mensagem': 'Produto adicionado com sucesso!'}), 201


@app.route('/')
def index():
    return send_from_directory('static', 'index.html')


if __name__ == '__main__':
    app.run(debug=True)
