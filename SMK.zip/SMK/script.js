const API_URL = 'http://127.0.0.1:5000/produtos';

async function carregarProdutos() {
    try {
        const res = await fetch(API_URL);
        const produtos = await res.json();
        const container = document.getElementById('produtos-container');
        container.innerHTML = '';

        produtos.forEach(produto => {
            const card = document.createElement('div');
            card.className = 'produto-card';
            card.innerHTML = `
                <img src="${produto.imagem}" alt="${produto.nome}" width="200" height="200">
><strong>Preço:</strong> R$ ${produto.preco.toFixed(2)}</p>
                <p><strong>Descrição:</strong> ${produto.descricao}</p>
                <button onclick="editarProduto(${produto.id}, '${produto.nome}', ${produto.preco}, '${produto.descricao}', '${produto.imagem}')">Editar</button>
                <button onclick="excluirProduto(${produto.id})">Excluir</button>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
    }
}

document.getElementById('form-produto').addEventListener('submit', async (e) => {
    e.preventDefault();

    const id = document.getElementById('id').value;
    const nome = document.getElementById('nome').value;
    const preco = parseFloat(document.getElementById('preco').value);
    const descricao = document.getElementById('descricao').value;
    const imagem = document.getElementById('imagem').value;

    const produto = { nome, preco, descricao, imagem };
    const metodo